import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Heart, 
  Brain,
  Target,
  Award,
  Zap
} from "lucide-react"

export function Dashboard() {
  const moodData = [
    { day: 'Mon', mood: 85, stress: 25 },
    { day: 'Tue', mood: 72, stress: 45 },
    { day: 'Wed', mood: 90, stress: 15 },
    { day: 'Thu', mood: 68, stress: 55 },
    { day: 'Fri', mood: 88, stress: 20 },
    { day: 'Sat', mood: 95, stress: 10 },
    { day: 'Sun', mood: 82, stress: 30 },
  ]

  const currentMood = 82
  const stressLevel = 30
  const weeklyProgress = 78
  const streakDays = 12

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Welcome back!</h2>
        <p className="text-muted-foreground">Here's your mental wellness overview</p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Mood</CardTitle>
            <Heart className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentMood}%</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +8% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stress Level</CardTitle>
            <Brain className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stressLevel}%</div>
            <p className="text-xs text-muted-foreground">
              <TrendingDown className="inline h-3 w-3 mr-1" />
              -12% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weekly Progress</CardTitle>
            <Target className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{weeklyProgress}%</div>
            <Progress value={weeklyProgress} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Streak Days</CardTitle>
            <Award className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{streakDays}</div>
            <p className="text-xs text-muted-foreground">
              Keep it up! 🔥
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Mood Chart */}
      <Card className="col-span-4">
        <CardHeader>
          <CardTitle>Weekly Mood & Stress Patterns</CardTitle>
          <CardDescription>
            Your emotional wellness trend over the past week
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {moodData.map((data, index) => (
              <div key={data.day} className="flex items-center space-x-4">
                <div className="w-12 text-sm font-medium">{data.day}</div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-green-600">Mood</span>
                    <Progress value={data.mood} className="flex-1 h-2 bg-green-100" />
                    <span className="text-xs font-medium w-8">{data.mood}%</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-red-600">Stress</span>
                    <Progress value={data.stress} className="flex-1 h-2 bg-red-100" />
                    <span className="text-xs font-medium w-8">{data.stress}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-blue-500" />
              <span>Quick Exercise</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Start a 5-minute breathing exercise to reduce stress
            </p>
            <Badge variant="secondary" className="mt-2">
              <Zap className="h-3 w-3 mr-1" />
              Instant Relief
            </Badge>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-500" />
              <span>AI Analysis</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Get personalized insights from your typing patterns
            </p>
            <Badge variant="secondary" className="mt-2">
              AI Powered
            </Badge>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Heart className="h-5 w-5 text-red-500" />
              <span>Mood Check-in</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Log your current feelings and get personalized recommendations
            </p>
            <Badge variant="secondary" className="mt-2">
              Quick Start
            </Badge>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}