import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { 
  Shield, 
  Lock, 
  Eye,
  Database,
  Trash2,
  Download,
  Settings,
  CheckCircle,
  AlertTriangle,
  Info
} from "lucide-react"

export function Privacy() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Privacy & Security</h2>
        <p className="text-muted-foreground">Your privacy is our top priority. Here's how we protect your data.</p>
      </div>

      {/* Privacy Overview */}
      <Alert className="border-green-200 bg-green-50">
        <Shield className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800">
          <strong>Your data stays private:</strong> We analyze typing patterns and metadata without storing your actual text content.
        </AlertDescription>
      </Alert>

      {/* Core Privacy Principles */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lock className="h-5 w-5 text-blue-500" />
              <span>Data Minimization</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Keystroke Metadata Only</h4>
                <p className="text-sm text-muted-foreground">
                  We collect typing speed, rhythm, and pressure patterns - never your actual text
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Local Processing</h4>
                <p className="text-sm text-muted-foreground">
                  AI analysis happens on your device when possible
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Automatic Deletion</h4>
                <p className="text-sm text-muted-foreground">
                  Raw keystroke data is deleted within 24 hours
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Eye className="h-5 w-5 text-purple-500" />
              <span>Transparency</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start space-x-3">
              <Info className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Open Source Components</h4>
                <p className="text-sm text-muted-foreground">
                  Key privacy components are open source for verification
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <Info className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Regular Audits</h4>
                <p className="text-sm text-muted-foreground">
                  Third-party security audits every 6 months
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <Info className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Clear Reports</h4>
                <p className="text-sm text-muted-foreground">
                  Monthly transparency reports on data handling
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Privacy Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5 text-gray-500" />
            <span>Privacy Controls</span>
          </CardTitle>
          <CardDescription>
            Manage what data we collect and how it's used
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-medium">Keystroke Analysis</h4>
                <p className="text-sm text-muted-foreground">Allow analysis of typing patterns for stress detection</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-medium">Mood Pattern Learning</h4>
                <p className="text-sm text-muted-foreground">Enable AI to learn your mood patterns for better recommendations</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-medium">Usage Analytics</h4>
                <p className="text-sm text-muted-foreground">Share anonymous usage data to improve the app</p>
              </div>
              <Switch />
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-medium">Research Participation</h4>
                <p className="text-sm text-muted-foreground">Contribute anonymized data to mental health research</p>
              </div>
              <Switch />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-green-500" />
            <span>Your Data</span>
          </CardTitle>
          <CardDescription>
            Control and manage your personal data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 border rounded-lg text-center">
              <Download className="h-8 w-8 mx-auto mb-2 text-blue-500" />
              <h4 className="font-medium">Export Data</h4>
              <p className="text-sm text-muted-foreground mb-3">Download all your data in JSON format</p>
              <Button variant="outline" size="sm">Download</Button>
            </div>

            <div className="p-4 border rounded-lg text-center">
              <Trash2 className="h-8 w-8 mx-auto mb-2 text-red-500" />
              <h4 className="font-medium">Delete Account</h4>
              <p className="text-sm text-muted-foreground mb-3">Permanently remove all your data</p>
              <Button variant="destructive" size="sm">Delete</Button>
            </div>

            <div className="p-4 border rounded-lg text-center">
              <Settings className="h-8 w-8 mx-auto mb-2 text-gray-500" />
              <h4 className="font-medium">Data Preferences</h4>
              <p className="text-sm text-muted-foreground mb-3">Customize data collection settings</p>
              <Button variant="outline" size="sm">Manage</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-green-500" />
            <span>Security Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">End-to-end encryption enabled</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Two-factor authentication active</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Latest security updates installed</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-yellow-500" />
                <span className="text-sm">Password last changed 45 days ago</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">No suspicious login attempts</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Chrome extension verified</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chrome Extension Privacy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5 text-blue-500" />
            <span>Chrome Extension Privacy</span>
          </CardTitle>
          <CardDescription>
            How our browser extension protects your privacy
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              The extension only monitors typing metadata on allowed sites. It cannot read your passwords, emails, or personal documents.
            </AlertDescription>
          </Alert>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h4 className="font-medium text-green-800 mb-2">What we monitor:</h4>
              <ul className="text-sm space-y-1 text-green-700">
                <li>• Typing speed and rhythm</li>
                <li>• Key press timing patterns</li>
                <li>• Pause duration between keys</li>
                <li>• General stress indicators</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-red-800 mb-2">What we never see:</h4>
              <ul className="text-sm space-y-1 text-red-700">
                <li>• Actual text content</li>
                <li>• Passwords or login details</li>
                <li>• Banking information</li>
                <li>• Personal documents</li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Site Permissions</h4>
            <p className="text-sm text-blue-700 mb-3">
              You can control which websites the extension monitors. By default, it excludes banking, email, and sensitive sites.
            </p>
            <Button size="sm" variant="outline">Manage Sites</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}