const mongoose = require('mongoose');

const exerciseSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  category: {
    type: String,
    enum: ['breathing', 'mindfulness', 'cognitive', 'physical', 'social'],
    required: true
  },
  difficulty: {
    type: String,
    enum: ['beginner', 'intermediate', 'advanced'],
    default: 'beginner'
  },
  duration: {
    type: Number, // in minutes
    required: true
  },
  description: {
    type: String,
    required: true
  },
  instructions: [String],
  benefits: [String],
  targetConditions: [String], // stress, anxiety, depression, etc.
  audioUrl: String,
  videoUrl: String,
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const exerciseSessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  exerciseId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Exercise',
    required: true
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: Date,
  duration: Number, // actual duration in seconds
  completed: {
    type: Boolean,
    default: false
  },
  rating: {
    type: Number,
    min: 1,
    max: 5
  },
  feedback: String,
  moodBefore: {
    type: Number,
    min: 1,
    max: 10
  },
  moodAfter: {
    type: Number,
    min: 1,
    max: 10
  },
  stressBefore: {
    type: Number,
    min: 0,
    max: 100
  },
  stressAfter: {
    type: Number,
    min: 0,
    max: 100
  }
});

// Indexes
exerciseSchema.index({ category: 1, difficulty: 1 });
exerciseSessionSchema.index({ userId: 1, startTime: -1 });

module.exports = {
  Exercise: mongoose.model('Exercise', exerciseSchema),
  ExerciseSession: mongoose.model('ExerciseSession', exerciseSessionSchema)
};