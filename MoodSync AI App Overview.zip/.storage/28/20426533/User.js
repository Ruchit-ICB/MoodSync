const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  profile: {
    firstName: String,
    lastName: String,
    dateOfBirth: Date,
    timezone: {
      type: String,
      default: 'UTC'
    }
  },
  preferences: {
    notifications: {
      stressAlerts: { type: Boolean, default: true },
      dailyCheckins: { type: Boolean, default: true },
      exerciseReminders: { type: Boolean, default: false },
      weeklyReports: { type: Boolean, default: true }
    },
    privacy: {
      keystrokeAnalysis: { type: Boolean, default: true },
      moodPatternLearning: { type: Boolean, default: true },
      usageAnalytics: { type: Boolean, default: false },
      researchParticipation: { type: Boolean, default: false }
    },
    ai: {
      sensitivity: { type: Number, default: 50, min: 0, max: 100 },
      realTimeAnalysis: { type: Boolean, default: true },
      predictiveInsights: { type: Boolean, default: true },
      personality: { 
        type: String, 
        enum: ['professional', 'supportive', 'friendly', 'motivational'], 
        default: 'supportive' 
      }
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  lastLogin: Date,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Password hashing middleware
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Remove sensitive data when converting to JSON
userSchema.methods.toJSON = function() {
  const userObject = this.toObject();
  delete userObject.password;
  return userObject;
};

module.exports = mongoose.model('User', userSchema);