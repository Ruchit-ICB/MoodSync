import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { 
  TrendingUp, 
  TrendingDown, 
  Brain, 
  Heart,
  Calendar,
  Clock,
  Target,
  Award,
  Activity,
  BarChart3
} from "lucide-react"

export function Insights() {
  const weeklyData = [
    { day: 'Monday', mood: 75, stress: 45, productivity: 80 },
    { day: 'Tuesday', mood: 82, stress: 35, productivity: 85 },
    { day: 'Wednesday', mood: 70, stress: 60, productivity: 70 },
    { day: 'Thursday', mood: 88, stress: 25, productivity: 90 },
    { day: 'Friday', mood: 92, stress: 20, productivity: 95 },
    { day: 'Saturday', mood: 95, stress: 15, productivity: 60 },
    { day: 'Sunday', mood: 85, stress: 30, productivity: 65 },
  ]

  const insights = [
    {
      title: "Peak Performance Time",
      description: "You perform best between 10 AM - 2 PM",
      icon: Clock,
      color: "text-blue-500",
      trend: "positive"
    },
    {
      title: "Stress Triggers",
      description: "Meetings and deadlines increase stress by 40%",
      icon: Brain,
      color: "text-red-500",
      trend: "negative"
    },
    {
      title: "Mood Boosters",
      description: "Exercise and social time improve mood by 35%",
      icon: Heart,
      color: "text-green-500",
      trend: "positive"
    },
    {
      title: "Weekly Pattern",
      description: "Wednesdays are your most challenging days",
      icon: Calendar,
      color: "text-orange-500",
      trend: "neutral"
    }
  ]

  const achievements = [
    { title: "7-Day Streak", description: "Consistent mood tracking", icon: Award, earned: true },
    { title: "Stress Buster", description: "Reduced stress by 30%", icon: Brain, earned: true },
    { title: "Mood Master", description: "5 days above 80% mood", icon: Heart, earned: false },
    { title: "Wellness Warrior", description: "30 days active", icon: Target, earned: false },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Insights & Analytics</h2>
        <p className="text-muted-foreground">Deep dive into your mental wellness patterns and progress</p>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Mood</CardTitle>
            <div className="text-2xl font-bold">8.3/10</div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 text-sm">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-green-600">+12% this week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Stress Reduction</CardTitle>
            <div className="text-2xl font-bold">-28%</div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 text-sm">
              <TrendingDown className="h-4 w-4 text-green-500" />
              <span className="text-green-600">Great progress!</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Productivity Score</CardTitle>
            <div className="text-2xl font-bold">82%</div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 text-sm">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              <span className="text-blue-600">+5% from last week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Wellness Score</CardTitle>
            <div className="text-2xl font-bold">A+</div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 text-sm">
              <Award className="h-4 w-4 text-yellow-500" />
              <span className="text-yellow-600">Excellent!</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-500" />
            <span>Weekly Breakdown</span>
          </CardTitle>
          <CardDescription>
            Your mood, stress, and productivity patterns throughout the week
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {weeklyData.map((data, index) => (
              <div key={data.day} className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{data.day}</span>
                  <div className="flex space-x-2">
                    <Badge variant="secondary">Mood: {data.mood}%</Badge>
                    <Badge variant={data.stress > 50 ? "destructive" : "secondary"}>
                      Stress: {data.stress}%
                    </Badge>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-green-600 w-16">Mood</span>
                    <Progress value={data.mood} className="flex-1 h-2" />
                    <span className="text-sm w-8">{data.mood}%</span>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-red-600 w-16">Stress</span>
                    <Progress value={data.stress} className="flex-1 h-2" />
                    <span className="text-sm w-8">{data.stress}%</span>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-blue-600 w-16">Focus</span>
                    <Progress value={data.productivity} className="flex-1 h-2" />
                    <span className="text-sm w-8">{data.productivity}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Insights */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-500" />
              <span>AI-Powered Insights</span>
            </CardTitle>
            <CardDescription>
              Personalized patterns discovered from your data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {insights.map((insight, index) => {
                const Icon = insight.icon
                return (
                  <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                    <Icon className={`h-5 w-5 ${insight.color} mt-0.5`} />
                    <div>
                      <h4 className="font-medium">{insight.title}</h4>
                      <p className="text-sm text-muted-foreground">{insight.description}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Award className="h-5 w-5 text-yellow-500" />
              <span>Achievements</span>
            </CardTitle>
            <CardDescription>
              Your mental wellness milestones
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon
                return (
                  <div key={index} className={`flex items-center space-x-3 p-3 rounded-lg ${
                    achievement.earned ? 'bg-green-50 border-green-200' : 'bg-gray-50'
                  }`}>
                    <div className={`p-2 rounded-full ${
                      achievement.earned ? 'bg-green-500' : 'bg-gray-300'
                    }`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{achievement.title}</h4>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                    </div>
                    {achievement.earned && (
                      <Badge className="bg-green-500">Earned</Badge>
                    )}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5 text-blue-500" />
            <span>Personalized Recommendations</span>
          </CardTitle>
          <CardDescription>
            Based on your patterns, here's how to optimize your wellness
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Clock className="h-4 w-4 text-blue-500" />
                <span className="font-medium">Schedule Optimization</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Schedule important tasks during your peak hours (10 AM - 2 PM) for better performance.
              </p>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Activity className="h-4 w-4 text-green-500" />
                <span className="font-medium">Wednesday Support</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Add extra self-care activities on Wednesdays to counter your challenging pattern.
              </p>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Heart className="h-4 w-4 text-red-500" />
                <span className="font-medium">Stress Prevention</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Practice breathing exercises before meetings to reduce stress triggers.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}