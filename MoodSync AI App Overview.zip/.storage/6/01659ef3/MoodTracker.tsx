import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Smile, 
  Meh, 
  Frown, 
  Heart, 
  Brain,
  Zap,
  Coffee,
  Moon,
  Sun,
  Cloud,
  CloudRain
} from "lucide-react"

export function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<number | null>(null)
  const [moodNote, setMoodNote] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const moodOptions = [
    { value: 1, label: "Very Sad", icon: Frown, color: "text-red-600", bg: "bg-red-50" },
    { value: 2, label: "Sad", icon: CloudRain, color: "text-orange-600", bg: "bg-orange-50" },
    { value: 3, label: "Neutral", icon: Meh, color: "text-gray-600", bg: "bg-gray-50" },
    { value: 4, label: "Happy", icon: Sun, color: "text-yellow-600", bg: "bg-yellow-50" },
    { value: 5, label: "Very Happy", icon: Smile, color: "text-green-600", bg: "bg-green-50" },
  ]

  const handleMoodSubmit = () => {
    setIsAnalyzing(true)
    // Simulate AI analysis
    setTimeout(() => {
      setIsAnalyzing(false)
      // Reset form
      setSelectedMood(null)
      setMoodNote("")
    }, 2000)
  }

  const recentEntries = [
    { date: "Today 2:30 PM", mood: 4, note: "Feeling productive after completing my project", stress: 25 },
    { date: "Today 10:15 AM", mood: 3, note: "Regular morning mood", stress: 40 },
    { date: "Yesterday 6:45 PM", mood: 5, note: "Great day with friends!", stress: 10 },
    { date: "Yesterday 2:20 PM", mood: 2, note: "Stressful meeting at work", stress: 75 },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Mood Tracker</h2>
        <p className="text-muted-foreground">Log your feelings and track patterns over time</p>
      </div>

      {/* Mood Entry */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Heart className="h-5 w-5 text-red-500" />
            <span>How are you feeling right now?</span>
          </CardTitle>
          <CardDescription>
            Your mood data helps our AI provide better personalized recommendations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-5 gap-4">
            {moodOptions.map((mood) => {
              const Icon = mood.icon
              return (
                <button
                  key={mood.value}
                  onClick={() => setSelectedMood(mood.value)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedMood === mood.value
                      ? `${mood.bg} border-current ${mood.color}`
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <Icon className={`h-8 w-8 mx-auto mb-2 ${mood.color}`} />
                  <div className="text-sm font-medium">{mood.label}</div>
                </button>
              )
            })}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Add a note (optional)</label>
            <Textarea
              placeholder="What's on your mind? Describe your current feelings or what's affecting your mood..."
              value={moodNote}
              onChange={(e) => setMoodNote(e.target.value)}
              rows={3}
            />
          </div>

          <Button 
            onClick={handleMoodSubmit}
            disabled={!selectedMood || isAnalyzing}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <Brain className="h-4 w-4 mr-2 animate-spin" />
                Analyzing with AI...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Save & Get AI Insights
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Recent Entries */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Mood Entries</CardTitle>
          <CardDescription>Your mood history and patterns</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentEntries.map((entry, index) => {
              const moodInfo = moodOptions.find(m => m.value === entry.mood)
              const Icon = moodInfo?.icon || Meh
              
              return (
                <div key={index} className="flex items-start space-x-4 p-4 rounded-lg bg-gray-50">
                  <div className={`p-2 rounded-full ${moodInfo?.bg}`}>
                    <Icon className={`h-5 w-5 ${moodInfo?.color}`} />
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium">{entry.date}</div>
                      <Badge variant="secondary">{moodInfo?.label}</Badge>
                    </div>
                    <p className="text-sm text-gray-600">{entry.note}</p>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-gray-500">Stress Level:</span>
                      <Progress value={entry.stress} className="flex-1 h-2" />
                      <span className="text-xs font-medium">{entry.stress}%</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Today's Average</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Sun className="h-5 w-5 text-yellow-500" />
              <span className="text-2xl font-bold">7.5/10</span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">Pretty good day!</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Week Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Coffee className="h-5 w-5 text-blue-500" />
              <span className="text-2xl font-bold">Improving</span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">+15% from last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Best Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Moon className="h-5 w-5 text-purple-500" />
              <span className="text-2xl font-bold">Evening</span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">6-8 PM peak mood</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}