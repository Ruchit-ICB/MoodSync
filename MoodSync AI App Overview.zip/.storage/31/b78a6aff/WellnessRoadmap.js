const mongoose = require('mongoose');

const roadmapSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  roadmapType: {
    type: String,
    enum: ['stress-management', 'mood-enhancement', 'anxiety-relief', 'sleep-improvement'],
    required: true
  },
  currentPhase: {
    type: Number,
    default: 1
  },
  progress: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  phases: [{
    phaseNumber: Number,
    title: String,
    description: String,
    duration: String,
    status: {
      type: String,
      enum: ['not-started', 'current', 'completed'],
      default: 'not-started'
    },
    activities: [{
      name: String,
      description: String,
      completed: { type: Boolean, default: false },
      completedAt: Date
    }],
    completedAt: Date
  }],
  achievements: [{
    id: String,
    name: String,
    description: String,
    earnedAt: Date,
    category: String
  }],
  personalizedGoals: [{
    goal: String,
    targetDate: Date,
    completed: { type: Boolean, default: false },
    completedAt: Date
  }],
  startedAt: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

// Middleware to update lastUpdated
roadmapSchema.pre('save', function(next) {
  this.lastUpdated = Date.now();
  next();
});

// Index for efficient querying
roadmapSchema.index({ userId: 1, roadmapType: 1 });

module.exports = mongoose.model('WellnessRoadmap', roadmapSchema);