const mongoose = require('mongoose');

const moodEntrySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  moodScore: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  stressLevel: {
    type: Number,
    min: 0,
    max: 100,
    default: null
  },
  note: {
    type: String,
    maxlength: 500,
    trim: true
  },
  metadata: {
    triggers: [String],
    activities: [String],
    location: String,
    weather: String
  },
  aiAnalysis: {
    sentiment: {
      score: Number,
      confidence: Number
    },
    emotionalState: {
      dominant: String,
      secondary: [String]
    },
    recommendations: [String],
    riskFactors: [String]
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

// Index for efficient querying
moodEntrySchema.index({ userId: 1, timestamp: -1 });
moodEntrySchema.index({ userId: 1, moodScore: 1 });

module.exports = mongoose.model('MoodEntry', moodEntrySchema);