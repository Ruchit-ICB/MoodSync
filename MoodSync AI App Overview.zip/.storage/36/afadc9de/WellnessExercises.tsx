import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Activity, 
  Brain, 
  Heart,
  Wind,
  Clock,
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  Zap
} from "lucide-react"

export function WellnessExercises() {
  const [activeExercise, setActiveExercise] = useState<string | null>(null)
  const [timer, setTimer] = useState(0)
  const [isRunning, setIsRunning] = useState(false)

  const exercises = {
    breathing: [
      {
        id: "478-breathing",
        name: "4-7-8 Breathing",
        description: "Calming technique to reduce anxiety and promote sleep",
        duration: "5 minutes",
        difficulty: "Beginner",
        benefits: ["Reduces anxiety", "Improves sleep", "Lowers stress"],
        instructions: [
          "Sit comfortably with your back straight",
          "Exhale completely through your mouth",
          "Inhale through your nose for 4 counts",
          "Hold your breath for 7 counts", 
          "Exhale through your mouth for 8 counts",
          "Repeat 3-4 cycles"
        ]
      },
      {
        id: "box-breathing",
        name: "Box Breathing",
        description: "Navy SEAL technique for focus and calm under pressure",
        duration: "10 minutes",
        difficulty: "Intermediate", 
        benefits: ["Improves focus", "Reduces stress", "Enhances performance"],
        instructions: [
          "Sit upright in a comfortable position",
          "Inhale for 4 counts",
          "Hold for 4 counts",
          "Exhale for 4 counts",
          "Hold empty for 4 counts",
          "Repeat for 10 minutes"
        ]
      }
    ],
    mindfulness: [
      {
        id: "body-scan",
        name: "Progressive Body Scan",
        description: "Release tension and increase body awareness",
        duration: "15 minutes",
        difficulty: "Beginner",
        benefits: ["Releases tension", "Improves awareness", "Promotes relaxation"],
        instructions: [
          "Lie down comfortably",
          "Close your eyes and breathe naturally",
          "Focus on your toes, notice any sensations",
          "Gradually move attention up your body",
          "Spend 1-2 minutes on each body part",
          "End at the top of your head"
        ]
      },
      {
        id: "mindful-walking",
        name: "Mindful Walking",
        description: "Meditation in motion for clarity and grounding",
        duration: "10 minutes",
        difficulty: "Beginner",
        benefits: ["Improves clarity", "Grounds emotions", "Increases awareness"],
        instructions: [
          "Choose a quiet path 10-20 steps long",
          "Walk slowly and deliberately",
          "Focus on the sensation of each step",
          "Notice when your mind wanders",
          "Gently return attention to walking",
          "Turn around mindfully at each end"
        ]
      }
    ],
    cognitive: [
      {
        id: "thought-challenging",
        name: "Thought Challenge",
        description: "Reframe negative thinking patterns",
        duration: "10 minutes",
        difficulty: "Intermediate",
        benefits: ["Reduces negative thinking", "Improves mood", "Builds resilience"],
        instructions: [
          "Identify a negative thought",
          "Ask: Is this thought helpful?",
          "Look for evidence for and against",
          "Consider alternative perspectives",
          "Create a balanced thought",
          "Practice the new thought"
        ]
      },
      {
        id: "gratitude-practice",
        name: "Gratitude Practice",
        description: "Shift focus to positive aspects of life",
        duration: "5 minutes",
        difficulty: "Beginner",
        benefits: ["Improves mood", "Increases happiness", "Reduces depression"],
        instructions: [
          "Find a comfortable position",
          "Think of 3 things you're grateful for",
          "Focus on why you're grateful for each",
          "Feel the emotion of gratitude",
          "Write them down if helpful",
          "End with appreciation for yourself"
        ]
      }
    ]
  }

  const startExercise = (exerciseId: string) => {
    setActiveExercise(exerciseId)
    setTimer(0)
    setIsRunning(true)
  }

  const pauseExercise = () => {
    setIsRunning(false)
  }

  const resetExercise = () => {
    setActiveExercise(null)
    setTimer(0)
    setIsRunning(false)
  }

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRunning) {
      interval = setInterval(() => {
        setTimer(timer => timer + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isRunning])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  interface Exercise {
    id: string;
    name: string;
    description: string;
    duration: string;
    difficulty: string;
    benefits: string[];
    instructions: string[];
  }

  const ExerciseCard = ({ exercise, category }: { exercise: Exercise; category: string }) => (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{exercise.name}</CardTitle>
            <CardDescription>{exercise.description}</CardDescription>
          </div>
          <Badge variant={exercise.difficulty === 'Beginner' ? 'secondary' : 'default'}>
            {exercise.difficulty}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>{exercise.duration}</span>
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-2">Benefits:</h4>
          <div className="flex flex-wrap gap-1">
            {exercise.benefits.map((benefit: string, index: number) => (
              <Badge key={index} variant="outline" className="text-xs">
                {benefit}
              </Badge>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-2">Instructions:</h4>
          <ol className="text-sm space-y-1">
            {exercise.instructions.map((step: string, index: number) => (
              <li key={index} className="flex items-start space-x-2">
                <span className="text-muted-foreground">{index + 1}.</span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        {activeExercise === exercise.id ? (
          <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold">{formatTime(timer)}</div>
              <p className="text-sm text-muted-foreground">Exercise in progress</p>
            </div>
            
            <div className="flex space-x-2">
              {isRunning ? (
                <Button onClick={pauseExercise} className="flex-1">
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </Button>
              ) : (
                <Button onClick={() => setIsRunning(true)} className="flex-1">
                  <Play className="h-4 w-4 mr-2" />
                  Resume
                </Button>
              )}
              <Button onClick={resetExercise} variant="outline">
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <Button onClick={() => startExercise(exercise.id)} className="w-full">
            <Play className="h-4 w-4 mr-2" />
            Start Exercise
          </Button>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Wellness Exercises</h2>
        <p className="text-muted-foreground">Guided practices for stress relief and mental well-being</p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-8 w-8 text-blue-500" />
              <div>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">Exercises Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-8 w-8 text-green-500" />
              <div>
                <div className="text-2xl font-bold">2h 15m</div>
                <p className="text-xs text-muted-foreground">Total Practice Time</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-red-500" />
              <div>
                <div className="text-2xl font-bold">5</div>
                <p className="text-xs text-muted-foreground">Day Streak</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-yellow-500" />
              <div>
                <div className="text-2xl font-bold">-25%</div>
                <p className="text-xs text-muted-foreground">Stress Reduction</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Exercise Categories */}
      <Tabs defaultValue="breathing" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="breathing" className="flex items-center space-x-2">
            <Wind className="h-4 w-4" />
            <span>Breathing</span>
          </TabsTrigger>
          <TabsTrigger value="mindfulness" className="flex items-center space-x-2">
            <Brain className="h-4 w-4" />
            <span>Mindfulness</span>
          </TabsTrigger>
          <TabsTrigger value="cognitive" className="flex items-center space-x-2">
            <Heart className="h-4 w-4" />
            <span>Cognitive</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="breathing" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {exercises.breathing.map((exercise) => (
              <ExerciseCard key={exercise.id} exercise={exercise} category="breathing" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="mindfulness" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {exercises.mindfulness.map((exercise) => (
              <ExerciseCard key={exercise.id} exercise={exercise} category="mindfulness" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="cognitive" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {exercises.cognitive.map((exercise) => (
              <ExerciseCard key={exercise.id} exercise={exercise} category="cognitive" />
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Today's Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            <span>Today's Recommendations</span>
          </CardTitle>
          <CardDescription>
            Based on your current stress level and mood patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 border rounded-lg bg-gradient-to-br from-blue-50 to-blue-100">
              <Wind className="h-8 w-8 text-blue-600 mb-2" />
              <h4 className="font-medium text-blue-800">Morning Breathing</h4>
              <p className="text-sm text-blue-700">Start your day with 4-7-8 breathing to set a calm tone.</p>
              <Button size="sm" className="mt-2" onClick={() => startExercise("478-breathing")}>
                Start Now
              </Button>
            </div>

            <div className="p-4 border rounded-lg bg-gradient-to-br from-green-50 to-green-100">
              <Brain className="h-8 w-8 text-green-600 mb-2" />
              <h4 className="font-medium text-green-800">Midday Reset</h4>
              <p className="text-sm text-green-700">Take a mindful walking break to refresh your mind.</p>
              <Button size="sm" variant="outline" className="mt-2" onClick={() => startExercise("mindful-walking")}>
                Try It
              </Button>
            </div>

            <div className="p-4 border rounded-lg bg-gradient-to-br from-purple-50 to-purple-100">
              <Heart className="h-8 w-8 text-purple-600 mb-2" />
              <h4 className="font-medium text-purple-800">Evening Gratitude</h4>
              <p className="text-sm text-purple-700">End your day by focusing on positive moments.</p>
              <Button size="sm" variant="outline" className="mt-2" onClick={() => startExercise("gratitude-practice")}>
                Practice
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}