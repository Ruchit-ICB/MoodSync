import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { 
  Home, 
  Brain, 
  MessageSquare, 
  TrendingUp, 
  Target, 
  Settings, 
  Heart,
  Activity,
  Shield
} from "lucide-react"

interface SidebarProps {
  currentPage: string
  onPageChange: (page: string) => void
}

export function Sidebar({ currentPage, onPageChange }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'mood-tracker', label: 'Mood Tracker', icon: Heart },
    { id: 'ai-analysis', label: 'AI Analysis', icon: Brain },
    { id: 'chatbot', label: 'AI Companion', icon: MessageSquare },
    { id: 'insights', label: 'Insights', icon: TrendingUp },
    { id: 'roadmap', label: 'Wellness Roadmap', icon: Target },
    { id: 'exercises', label: 'Exercises', icon: Activity },
    { id: 'privacy', label: 'Privacy', icon: Shield },
    { id: 'settings', label: 'Settings', icon: Settings },
  ]

  return (
    <div className="flex flex-col h-full w-64 bg-card border-r border-border">
      <div className="p-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            MoodSync
          </h1>
        </div>
      </div>
      
      <nav className="flex-1 px-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon
          return (
            <Button
              key={item.id}
              variant={currentPage === item.id ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start space-x-2",
                currentPage === item.id && "bg-blue-50 text-blue-700 border-blue-200"
              )}
              onClick={() => onPageChange(item.id)}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </Button>
          )
        })}
      </nav>
      
      <div className="p-4 border-t">
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Shield className="w-4 h-4" />
          <span>Privacy Protected</span>
        </div>
      </div>
    </div>
  )
}