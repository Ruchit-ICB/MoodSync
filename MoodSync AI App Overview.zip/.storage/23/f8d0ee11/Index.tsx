import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Dashboard } from '@/components/Dashboard'
import { MoodTracker } from '@/components/MoodTracker'
import { AIAnalysis } from '@/components/AIAnalysis'
import { Chatbot } from '@/components/Chatbot'
import { Insights } from '@/components/Insights'
import { WellnessRoadmap } from '@/components/WellnessRoadmap'
import { WellnessExercises } from '@/components/WellnessExercises'
import { Privacy } from '@/components/Privacy'
import { Settings } from '@/components/Settings'

export default function MoodSyncApp() {
  const [currentPage, setCurrentPage] = useState('dashboard')

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />
      case 'mood-tracker':
        return <MoodTracker />
      case 'ai-analysis':
        return <AIAnalysis />
      case 'chatbot':
        return <Chatbot />
      case 'insights':
        return <Insights />
      case 'roadmap':
        return <WellnessRoadmap />
      case 'exercises':
        return <WellnessExercises />
      case 'privacy':
        return <Privacy />
      case 'settings':
        return <Settings />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {renderPage()}
        </div>
      </main>
    </div>
  )
}
