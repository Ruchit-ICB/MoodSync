import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Brain, 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  Clock,
  Keyboard,
  Eye,
  Shield,
  Zap
} from "lucide-react"

export function AIAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisComplete, setAnalysisComplete] = useState(false)
  const [typingMetrics, setTypingMetrics] = useState({
    wpm: 0,
    accuracy: 0,
    pressure: 0,
    rhythm: 0
  })

  const startAnalysis = () => {
    setIsAnalyzing(true)
    setAnalysisComplete(false)
    
    // Simulate real-time analysis
    setTimeout(() => {
      setTypingMetrics({
        wpm: 45 + Math.random() * 20,
        accuracy: 85 + Math.random() * 15,
        pressure: Math.random() * 100,
        rhythm: 60 + Math.random() * 40
      })
      setIsAnalyzing(false)
      setAnalysisComplete(true)
    }, 3000)
  }

  const analysisResults = {
    stressLevel: 32,
    moodScore: 78,
    focusLevel: 85,
    fatigueLevel: 25,
    recommendations: [
      "Take a 5-minute breathing break",
      "Consider a short walk to reduce stress",
      "Your typing shows good focus - keep it up!",
      "Stay hydrated to maintain energy levels"
    ]
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">AI Analysis</h2>
        <p className="text-muted-foreground">Real-time stress and mood detection through typing patterns</p>
      </div>

      {/* Privacy Notice */}
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <strong>Privacy Protected:</strong> We analyze typing metadata (speed, rhythm, pressure) without storing your actual text content.
        </AlertDescription>
      </Alert>

      {/* Analysis Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-500" />
            <span>Live Typing Analysis</span>
          </CardTitle>
          <CardDescription>
            Start typing to get real-time insights into your stress and mood levels
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isAnalyzing && !analysisComplete && (
            <Button onClick={startAnalysis} className="w-full" size="lg">
              <Activity className="h-4 w-4 mr-2" />
              Start AI Analysis
            </Button>
          )}
          
          {isAnalyzing && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Brain className="h-5 w-5 animate-pulse text-purple-500" />
                <span className="text-lg font-medium">Analyzing typing patterns...</span>
              </div>
              <Progress value={66} className="w-full" />
              <p className="text-sm text-muted-foreground">
                AI is processing your keystroke dynamics, timing, and rhythm patterns
              </p>
            </div>
          )}

          {analysisComplete && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">Analysis Complete</span>
              </div>
              <Button onClick={startAnalysis} variant="outline" className="w-full">
                <Zap className="h-4 w-4 mr-2" />
                Run New Analysis
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Typing Metrics */}
      {analysisComplete && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <Keyboard className="h-4 w-4" />
                <span>Words/Min</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(typingMetrics.wpm)}</div>
              <Progress value={typingMetrics.wpm} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <Eye className="h-4 w-4" />
                <span>Accuracy</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(typingMetrics.accuracy)}%</div>
              <Progress value={typingMetrics.accuracy} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <Activity className="h-4 w-4" />
                <span>Key Pressure</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(typingMetrics.pressure)}%</div>
              <Progress value={typingMetrics.pressure} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <span>Rhythm</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(typingMetrics.rhythm)}%</div>
              <Progress value={typingMetrics.rhythm} className="mt-2" />
            </CardContent>
          </Card>
        </div>
      )}

      {/* AI Results */}
      {analysisComplete && (
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5 text-purple-500" />
                <span>AI Insights</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Stress Level</span>
                  <Badge variant={analysisResults.stressLevel < 40 ? "secondary" : "destructive"}>
                    {analysisResults.stressLevel}%
                  </Badge>
                </div>
                <Progress value={analysisResults.stressLevel} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Mood Score</span>
                  <Badge variant="secondary">{analysisResults.moodScore}%</Badge>
                </div>
                <Progress value={analysisResults.moodScore} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Focus Level</span>
                  <Badge variant="secondary">{analysisResults.focusLevel}%</Badge>
                </div>
                <Progress value={analysisResults.focusLevel} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Fatigue Level</span>
                  <Badge variant={analysisResults.fatigueLevel < 30 ? "secondary" : "destructive"}>
                    {analysisResults.fatigueLevel}%
                  </Badge>
                </div>
                <Progress value={analysisResults.fatigueLevel} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                <span>Recommendations</span>
              </CardTitle>
              <CardDescription>
                Personalized suggestions based on your current state
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {analysisResults.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-start space-x-2 p-3 bg-blue-50 rounded-lg">
                    <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{rec}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Chrome Extension Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-blue-500" />
            <span>Chrome Extension Integration</span>
          </CardTitle>
          <CardDescription>
            Install our Chrome extension for seamless background monitoring
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start space-x-3 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
            <Activity className="h-5 w-5 text-blue-500 mt-0.5" />
            <div>
              <h4 className="font-medium">Background Analysis</h4>
              <p className="text-sm text-muted-foreground">
                Continuous monitoring of typing patterns across all websites while maintaining privacy
              </p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
            <AlertTriangle className="h-5 w-5 text-orange-500 mt-0.5" />
            <div>
              <h4 className="font-medium">Smart Alerts</h4>
              <p className="text-sm text-muted-foreground">
                Get notifications when stress levels are detected, with instant relief suggestions
              </p>
            </div>
          </div>
          
          <Button className="w-full" variant="outline">
            Download Chrome Extension
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}