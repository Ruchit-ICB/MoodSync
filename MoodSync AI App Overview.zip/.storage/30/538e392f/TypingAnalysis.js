const mongoose = require('mongoose');

const typingAnalysisSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  sessionId: {
    type: String,
    required: true
  },
  metrics: {
    wpm: {
      type: Number,
      required: true
    },
    accuracy: {
      type: Number,
      min: 0,
      max: 100
    },
    keystrokePatterns: {
      avgDwellTime: Number,
      avgFlightTime: Number,
      rhythmVariability: Number,
      pressureIntensity: Number
    },
    pauseAnalysis: {
      shortPauses: Number,
      mediumPauses: Number,
      longPauses: Number,
      averagePauseLength: Number
    }
  },
  aiPredictions: {
    stressLevel: {
      type: Number,
      min: 0,
      max: 100
    },
    moodScore: {
      type: Number,
      min: 0,
      max: 100
    },
    fatigueLevel: {
      type: Number,
      min: 0,
      max: 100
    },
    focusLevel: {
      type: Number,
      min: 0,
      max: 100
    },
    confidence: {
      type: Number,
      min: 0,
      max: 1
    }
  },
  contextualData: {
    timeOfDay: String,
    dayOfWeek: String,
    applicationContext: String,
    workingHours: Boolean
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    default: Date.now,
    expires: 86400 // 24 hours - auto-delete for privacy
  }
});

// Indexes for efficient querying
typingAnalysisSchema.index({ userId: 1, timestamp: -1 });
typingAnalysisSchema.index({ sessionId: 1 });
typingAnalysisSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('TypingAnalysis', typingAnalysisSchema);