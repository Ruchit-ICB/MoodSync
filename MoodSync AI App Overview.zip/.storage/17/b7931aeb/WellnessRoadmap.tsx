import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Target, 
  CheckCircle, 
  Clock, 
  Brain,
  Heart,
  Activity,
  Users,
  Book,
  Calendar,
  Award,
  ArrowRight
} from "lucide-react"

export function WellnessRoadmap() {
  const [selectedGoal, setSelectedGoal] = useState("stress-management")

  const roadmapPhases = {
    "stress-management": {
      title: "Stress Management Mastery",
      description: "Build resilience and learn effective stress coping strategies",
      duration: "8 weeks",
      progress: 35,
      phases: [
        {
          phase: 1,
          title: "Awareness & Foundation",
          weeks: "Week 1-2",
          status: "completed",
          activities: [
            { name: "Stress trigger identification", completed: true },
            { name: "Daily mood tracking setup", completed: true },
            { name: "Basic breathing techniques", completed: true },
            { name: "Sleep hygiene assessment", completed: false }
          ]
        },
        {
          phase: 2,
          title: "Core Techniques",
          weeks: "Week 3-4",
          status: "current",
          activities: [
            { name: "Progressive muscle relaxation", completed: true },
            { name: "Mindfulness meditation (10 min daily)", completed: false },
            { name: "Cognitive reframing exercises", completed: false },
            { name: "Time management strategies", completed: false }
          ]
        },
        {
          phase: 3,
          title: "Advanced Strategies",
          weeks: "Week 5-6",
          status: "upcoming",
          activities: [
            { name: "Stress inoculation training", completed: false },
            { name: "Emotional regulation techniques", completed: false },
            { name: "Boundary setting practice", completed: false },
            { name: "Support network building", completed: false }
          ]
        },
        {
          phase: 4,
          title: "Integration & Maintenance",
          weeks: "Week 7-8",
          status: "upcoming",
          activities: [
            { name: "Personalized toolkit creation", completed: false },
            { name: "Relapse prevention planning", completed: false },
            { name: "Long-term goal setting", completed: false },
            { name: "Progress celebration", completed: false }
          ]
        }
      ]
    },
    "mood-enhancement": {
      title: "Mood Enhancement Journey",
      description: "Develop lasting habits for emotional well-being and happiness",
      duration: "6 weeks",
      progress: 50,
      phases: [
        {
          phase: 1,
          title: "Mood Awareness",
          weeks: "Week 1-2",
          status: "completed",
          activities: [
            { name: "Emotion identification practice", completed: true },
            { name: "Mood pattern analysis", completed: true },
            { name: "Gratitude journaling setup", completed: true }
          ]
        },
        {
          phase: 2,
          title: "Positive Psychology",
          weeks: "Week 3-4",
          status: "current",
          activities: [
            { name: "Strengths identification", completed: true },
            { name: "Positive activity scheduling", completed: false },
            { name: "Social connection building", completed: false }
          ]
        },
        {
          phase: 3,
          title: "Sustainable Happiness",
          weeks: "Week 5-6",
          status: "upcoming",
          activities: [
            { name: "Purpose and meaning exploration", completed: false },
            { name: "Flow state cultivation", completed: false },
            { name: "Resilience building", completed: false }
          ]
        }
      ]
    }
  }

  const currentRoadmap = roadmapPhases[selectedGoal as keyof typeof roadmapPhases]

  const achievements = [
    { name: "First Week Complete", icon: Calendar, earned: true },
    { name: "Breathing Master", icon: Activity, earned: true },
    { name: "Mood Tracker", icon: Heart, earned: true },
    { name: "Stress Buster", icon: Brain, earned: false },
    { name: "Wellness Champion", icon: Award, earned: false }
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Wellness Roadmap</h2>
        <p className="text-muted-foreground">Your personalized journey to mental wellness mastery</p>
      </div>

      {/* Roadmap Selection */}
      <Tabs value={selectedGoal} onValueChange={setSelectedGoal}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="stress-management">Stress Management</TabsTrigger>
          <TabsTrigger value="mood-enhancement">Mood Enhancement</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedGoal} className="space-y-6">
          {/* Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-blue-500" />
                <span>{currentRoadmap.title}</span>
              </CardTitle>
              <CardDescription>{currentRoadmap.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Overall Progress</span>
                <Badge variant="secondary">{currentRoadmap.progress}% Complete</Badge>
              </div>
              <Progress value={currentRoadmap.progress} className="w-full" />
              
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>Duration: {currentRoadmap.duration}</span>
                <span>Phase {currentRoadmap.phases.findIndex(p => p.status === 'current') + 1} of {currentRoadmap.phases.length}</span>
              </div>
            </CardContent>
          </Card>

          {/* Phases */}
          <div className="space-y-4">
            {currentRoadmap.phases.map((phase, index) => (
              <Card key={phase.phase} className={`${
                phase.status === 'current' ? 'border-blue-500 bg-blue-50' : 
                phase.status === 'completed' ? 'border-green-500 bg-green-50' : 
                'border-gray-200'
              }`}>
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        phase.status === 'completed' ? 'bg-green-500' :
                        phase.status === 'current' ? 'bg-blue-500' :
                        'bg-gray-300'
                      }`}>
                        {phase.status === 'completed' ? (
                          <CheckCircle className="h-5 w-5 text-white" />
                        ) : (
                          <span className="text-white font-bold">{phase.phase}</span>
                        )}
                      </div>
                      <span>Phase {phase.phase}: {phase.title}</span>
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">{phase.weeks}</span>
                      <Badge variant={
                        phase.status === 'completed' ? 'default' :
                        phase.status === 'current' ? 'secondary' :
                        'outline'
                      }>
                        {phase.status === 'completed' ? 'Completed' :
                         phase.status === 'current' ? 'In Progress' :
                         'Upcoming'}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-3">
                    {phase.activities.map((activity, actIndex) => (
                      <div key={actIndex} className="flex items-center space-x-3">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                          activity.completed ? 'bg-green-500' : 'bg-gray-200'
                        }`}>
                          {activity.completed && (
                            <CheckCircle className="h-3 w-3 text-white" />
                          )}
                        </div>
                        <span className={`flex-1 ${
                          activity.completed ? 'line-through text-muted-foreground' : ''
                        }`}>
                          {activity.name}
                        </span>
                        {phase.status === 'current' && !activity.completed && (
                          <Button size="sm" variant="outline">
                            Start
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>

                  {phase.status === 'current' && (
                    <div className="mt-4 p-4 bg-blue-100 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Brain className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-800">Current Focus</span>
                      </div>
                      <p className="text-sm text-blue-700">
                        You're currently working on building core techniques for stress management. 
                        Focus on completing your mindfulness practice this week!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Next Steps */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ArrowRight className="h-5 w-5 text-green-500" />
                <span>Next Steps</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="p-4 border rounded-lg">
                  <Activity className="h-8 w-8 text-blue-500 mb-2" />
                  <h4 className="font-medium">Complete Daily Practice</h4>
                  <p className="text-sm text-muted-foreground">
                    Finish your 10-minute mindfulness session
                  </p>
                  <Button size="sm" className="mt-2">Start Now</Button>
                </div>

                <div className="p-4 border rounded-lg">
                  <Book className="h-8 w-8 text-purple-500 mb-2" />
                  <h4 className="font-medium">Read Module</h4>
                  <p className="text-sm text-muted-foreground">
                    Learn about cognitive reframing techniques
                  </p>
                  <Button size="sm" variant="outline" className="mt-2">Read</Button>
                </div>

                <div className="p-4 border rounded-lg">
                  <Users className="h-8 w-8 text-green-500 mb-2" />
                  <h4 className="font-medium">Join Community</h4>
                  <p className="text-sm text-muted-foreground">
                    Connect with others on similar journeys
                  </p>
                  <Button size="sm" variant="outline" className="mt-2">Connect</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Award className="h-5 w-5 text-yellow-500" />
                <span>Journey Achievements</span>
              </CardTitle>
              <CardDescription>
                Celebrate your progress milestones
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-5">
                {achievements.map((achievement, index) => {
                  const Icon = achievement.icon
                  return (
                    <div key={index} className={`text-center p-4 rounded-lg ${
                      achievement.earned ? 'bg-yellow-50 border-yellow-200' : 'bg-gray-50'
                    }`}>
                      <div className={`w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-2 ${
                        achievement.earned ? 'bg-yellow-500' : 'bg-gray-300'
                      }`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <h4 className="font-medium text-sm">{achievement.name}</h4>
                      {achievement.earned && (
                        <Badge className="bg-yellow-500 mt-1">Earned</Badge>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}