import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { 
  MessageSquare, 
  Send, 
  Bot, 
  User,
  Heart,
  Brain,
  Lightbulb,
  Smile,
  Activity
} from "lucide-react"

interface Message {
  id: string
  type: 'user' | 'bot'
  content: string
  timestamp: Date
  suggestions?: string[]
}

export function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hi there! I'm your AI wellness companion. I'm here to help you manage stress, improve your mood, and support your mental well-being. How are you feeling today?",
      timestamp: new Date(),
      suggestions: ["I'm feeling stressed", "I'm doing okay", "I'm feeling great!", "I need some advice"]
    }
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const botResponses = {
    stressed: {
      content: "I understand you're feeling stressed. That's completely normal and you're not alone. Let's work through this together. Can you tell me what's causing the stress right now?",
      suggestions: ["Work pressure", "Personal relationships", "Financial concerns", "Health worries", "I'd rather not say"]
    },
    okay: {
      content: "It's great that you're doing okay! Maintaining emotional balance is important. Is there anything specific you'd like to work on or discuss today?",
      suggestions: ["Improve my mood", "Better sleep habits", "Stress management", "Building resilience", "Nothing specific"]
    },
    great: {
      content: "That's wonderful to hear! I love your positive energy. When we're feeling good, it's a perfect time to build healthy habits and resilience for the future. What would you like to focus on?",
      suggestions: ["Maintain this mood", "Learn new techniques", "Help others", "Set goals", "Practice gratitude"]
    },
    advice: {
      content: "I'm here to help! I can provide guidance on stress management, mood improvement, mindfulness techniques, and building emotional resilience. What specific area would you like advice on?",
      suggestions: ["Breathing exercises", "Mindfulness tips", "Sleep better", "Manage anxiety", "Build confidence"]
    },
    work: {
      content: "Work-related stress is very common. Here are some strategies that can help: Take regular breaks, practice deep breathing, prioritize tasks, and set boundaries. Would you like me to guide you through a quick stress-relief exercise?",
      suggestions: ["Yes, breathing exercise", "Time management tips", "Boundary setting", "Talk to someone", "Take a break"]
    },
    breathing: {
      content: "Perfect! Let's do the 4-7-8 breathing technique: \n\n1. Breathe in through your nose for 4 counts\n2. Hold your breath for 7 counts\n3. Exhale slowly through your mouth for 8 counts\n\nRepeat 3-4 times. This activates your parasympathetic nervous system and reduces stress. Ready to try?",
      suggestions: ["Start the exercise", "Different technique", "Tell me more", "I'm ready"]
    }
  }

  const handleSendMessage = (message: string) => {
    if (!message.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: message,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate bot response
    setTimeout(() => {
      const botResponse = generateBotResponse(message.toLowerCase())
      setMessages(prev => [...prev, botResponse])
      setIsTyping(false)
    }, 1500)
  }

  const generateBotResponse = (message: string): Message => {
    let response = botResponses.advice

    if (message.includes('stress') || message.includes('anxious')) {
      response = botResponses.stressed
    } else if (message.includes('okay') || message.includes('fine')) {
      response = botResponses.okay
    } else if (message.includes('great') || message.includes('good') || message.includes('happy')) {
      response = botResponses.great
    } else if (message.includes('work') || message.includes('job')) {
      response = botResponses.work
    } else if (message.includes('breathing') || message.includes('breath')) {
      response = botResponses.breathing
    }

    return {
      id: Date.now().toString(),
      type: 'bot',
      content: response.content,
      timestamp: new Date(),
      suggestions: response.suggestions
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion)
  }

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">AI Companion</h2>
        <p className="text-muted-foreground">Your personal mental wellness support chatbot</p>
      </div>

      <Card className="h-[600px] flex flex-col">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center space-x-2">
            <Bot className="h-5 w-5 text-blue-500" />
            <span>MoodSync AI Companion</span>
            <Badge variant="secondary" className="ml-auto">Online</Badge>
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col space-y-4">
          <ScrollArea className="flex-1 pr-4" ref={scrollAreaRef}>
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] space-y-2 ${message.type === 'user' ? 'order-2' : 'order-1'}`}>
                    <div className={`flex items-center space-x-2 ${message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        message.type === 'user' 
                          ? 'bg-blue-500' 
                          : 'bg-gradient-to-br from-purple-500 to-blue-500'
                      }`}>
                        {message.type === 'user' ? (
                          <User className="w-4 h-4 text-white" />
                        ) : (
                          <Bot className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    
                    <div className={`p-3 rounded-lg ${
                      message.type === 'user' 
                        ? 'bg-blue-500 text-white ml-10' 
                        : 'bg-gray-100 text-gray-900 mr-10'
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>

                    {message.suggestions && (
                      <div className="flex flex-wrap gap-2 mr-10">
                        {message.suggestions.map((suggestion, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="text-xs"
                          >
                            {suggestion}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-gray-100 p-3 rounded-lg">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="flex space-x-2">
            <Input
              placeholder="Type your message..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
              className="flex-1"
            />
            <Button 
              onClick={() => handleSendMessage(inputValue)}
              disabled={!inputValue.trim() || isTyping}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleSendMessage("I need a breathing exercise")}
              className="text-xs"
            >
              <Activity className="h-3 w-3 mr-1" />
              Breathing
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleSendMessage("I'm feeling stressed")}
              className="text-xs"
            >
              <Brain className="h-3 w-3 mr-1" />
              Stress Help
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleSendMessage("Give me motivation")}
              className="text-xs"
            >
              <Heart className="h-3 w-3 mr-1" />
              Motivation
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleSendMessage("Mindfulness tips")}
              className="text-xs"
            >
              <Lightbulb className="h-3 w-3 mr-1" />
              Tips
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}